/*
 * Date: 26 October, 2018
 * Author: Dave Castaldo
 * File: LineTest.java
 * Purpose: This is a test class used to quickly verify that the progam output is as expected.
 */
package bowlingscore;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author djcastaldo
 */
public class LineTest {
    
    public LineTest() {
    }
    

    /**
     * Test of getTotalScore method, of class Line.
     */
    @Test
    public void testGetTotalScore() {
        System.out.println("getTotalScore");
        // test input 1
        Line instance = new Line("XXXXXXXXXXXX");
        int expResult = 300;
        int result = instance.getTotalScore();
        assertEquals(expResult, result);
        // test input 2
        Line instance2 = new Line("9-9-9-9-9-9-9-9-9-9-");
        expResult = 90;
        result = instance2.getTotalScore();
        assertEquals(expResult, result);
        // test input 3
        Line instance3 = new Line("5/5/5/5/5/5/5/5/5/5/5");
        expResult = 150;
        result = instance3.getTotalScore();
        assertEquals(expResult, result);
        // test input 4
        Line instance4 = new Line("X7/9-X-88/-6XXX81");
        expResult = 167;
        result = instance4.getTotalScore();
        assertEquals(expResult, result);
        
                
    }

    /**
     * Test of translateNextRolls method, of class Line.
     */
    @Test
    public void testTranslateNextRolls() {
        System.out.println("translateNextRolls");
        char[] rolls = {'X','X'};
        Line instance = new Line("XXXXXXXXXXXX");
        int expResult = 20;
        int result = instance.translateNextRolls(rolls);
        assertEquals(expResult, result);
    }
    
}
