/*
 * Date: 26 October, 2018
 * Author: Dave Castaldo
 * File: Line.java
 * Purpose: This class stores a bowling line and calculates the total score
 */
package bowlingscore;

/**
 *
 * @author djcastaldo
 */
public class Line {
    private final String LINE_DATA;
    private int totalScore;
    
    public Line(String lineData) {
        // replace - with 0 in the lineData
        this.LINE_DATA = lineData.replace('-', '0');
        // run method to calculate the score
        calculateScore();
    }
    // public getter
    public int getTotalScore() {
        return totalScore;
    }
    
    private void calculateScore() {
        // get the size of the input
        int lineSize = LINE_DATA.length();
        // the current frame number
        int frame = 1;
        // iterate through the array, keeping track of frames   
        for (int i = 0; i < LINE_DATA.length() && frame < 11; i++) {
            char roll = LINE_DATA.charAt(i);
            char rollTwo = LINE_DATA.charAt(i+1);
            int frameScore;
            // if a strike, the frame score is the strike, + the next two rolls
            if (Character.toLowerCase(roll) == 'x') {
                // get next two rolls
                char[] nextTwoChar = {LINE_DATA.charAt(i+1), LINE_DATA.charAt(i+2)};
                // translate the numeric total of the next two rolls
                frameScore = 10 + translateNextRolls(nextTwoChar);
                totalScore += frameScore;
                // strike rolled, this frame is finished
                frame++;
                continue;
            } 
            if (rollTwo == '/') {
                // get next roll
                char[] nextChar = {LINE_DATA.charAt(i+2)};
                frameScore = 10 + translateNextRolls(nextChar);
                totalScore += frameScore;
                // spare rolled, this frame is finished
                i++;
                frame++;
                continue;
            }
            // if not strike or spare, just add the two rolls for the frame
            totalScore += Character.getNumericValue(roll) + Character.getNumericValue(rollTwo);
            i++;
            frame++;
        }
    }
    // this method can be used to get an integer value from an array of char
    // it is used to get the value of bonus rolls for a strike or spare
    public int translateNextRolls(char[] rolls) {
        int translated = 0;
        for (int i = 0; i < rolls.length; i++ ) {
            if (Character.toLowerCase(rolls[i]) == 'x') {
                translated += 10;
            } else if (rolls[i] == '/') {
                translated += 10 - Character.getNumericValue(rolls[i-1]);
            } else {
                translated += Character.getNumericValue(rolls[i]);
            }
        }
        return translated;
    }
}
