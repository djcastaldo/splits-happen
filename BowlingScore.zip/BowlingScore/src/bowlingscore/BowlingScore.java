/*
 * Date: 26 October, 2018
 * Author: Dave Castaldo
 * File: BowlingScore.java
 * Purpose: This class runs a loop to prompt the user for a bowling line.
 * An instance of the Line class is then created to calculate a score.
 */
package bowlingscore;

import java.util.Scanner;

/**
 *
 * @author djcastaldo
 */
public class BowlingScore {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // do a loop until user quits
        while (true) {
            System.out.print("Enter the Bowling Line (or q to quit): ");
            Scanner scannerIn = new Scanner(System.in,"UTF-8");
            String userInput = scannerIn.nextLine();
            if ("q".equals(userInput.toLowerCase())) {
                break;
            }
            // create an instance of the Line class
            Line bowlingLine = new Line(userInput.toLowerCase());
            // output the score
            System.out.println("Total Score:");
            System.out.println(bowlingLine.getTotalScore());
        }
    }
    
}
